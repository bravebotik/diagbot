<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'auth_webservice', language 'ru', version '4.5'.
 *
 * @package     auth_webservice
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['auth_webservicedescription'] = 'Этот способ аутентификации должен использоваться только для тех учетных записей, которые используются клиентами веб-служб Moodle';
$string['pluginname'] = 'Аутентификация для клиентов веб-служб';
$string['privacy:metadata'] = 'Плагин аутентификации «Аутентификация для клиентов веб-служб» не хранит никаких персональных данных.';
